---
name: Precision Sonic
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#464555'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4d44e3'
  primary: '#3525cd'
  on-primary: '#ffffff'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#c3c0ff'
  secondary: '#0051d5'
  on-secondary: '#ffffff'
  secondary-container: '#316bf3'
  on-secondary-container: '#fefcff'
  tertiary: '#00505f'
  on-tertiary: '#ffffff'
  tertiary-container: '#006a7c'
  on-tertiary-container: '#93e8ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b4c5ff'
  on-secondary-fixed: '#00174b'
  on-secondary-fixed-variant: '#003ea8'
  tertiary-fixed: '#acedff'
  tertiary-fixed-dim: '#4cd7f6'
  on-tertiary-fixed: '#001f26'
  on-tertiary-fixed-variant: '#004e5c'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Geist
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
    letterSpacing: -0.03em
  display-lg-mobile:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Geist
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Geist
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-sm:
    fontFamily: Geist
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.005em
  label-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  mono-timestamp:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  space-3xl: 4.5rem
  gutter-mobile: 1rem
  gutter-desktop: 1.5rem
  container-max: 80rem
---

## Brand & Style
The design system delivers an editorial, high-performance workspace tailored for audio processing, automated speech-to-text intelligence, and editorial transcription workflows. The interface prioritizes cognitive clarity, precision, and frictionless creation. It combines engineering-grade utility with refined modern minimalism—eliminating unnecessary embellishments to foreground sonic data, timestamps, speaker tracks, and text confidence scores.

Visual principles:
- **Calm Authority:** Muted slate surfaces and surgical spacing create an environment of focus and absolute reliability.
- **Electric Precision:** High-contrast sapphire and deep indigo accents isolate interactive focal points, active playback heads, and real-time audio waveforms.
- **Architectural Clarity:** Generous whitespace, precise hairline grid divisions, and deliberate typography guide scanning without visual clutter.

## Colors
The palette balances warm neutral slates with an electric sapphire and indigo focal core. The background hierarchy maintains absolute luminance contrast for extended reading and transcript editing.

- **Background & Canvas:**
  - Base canvas: `#FAFAF9` (warm studio neutral)
  - Surface panel/card: `#FFFFFF`
  - Subtle layer fill: `#F8FAFC`
- **Borders & Dividers:**
  - Ultra-subtle divider: `#F1F5F9`
  - Crisp boundary line: `#E2E8F0`
  - Focused interactive border: `#CBD5E1`
- **Text & Hierarchy:**
  - Primary text: `#0F172A` (deep slate-black)
  - Secondary text: `#475569`
  - Tertiary/Timestamp metadata: `#94A3B8`
  - Disabled/Ghost text: `#CBD5E1`
- **Accents & Active Feedback:**
  - Primary Indigo Accent: `#4F46E5` (interactive triggers, selected states, scrub heads)
  - Electric Sapphire: `#2563EB` (waveform active fills, dynamic transcription indicators)
  - Cyan Tertiary: `#06B6D4` (speaker badges, confidence markers)
  - Semantic Success: `#10B981` (processing complete)
  - Semantic Error: `#EF4444` (upload failure, dropped segments)

## Typography
Typographic rhythm is driven by Geist’s neutral geometric balance, augmented by monospaced numeric scales for audio metrics and timestamps.

- **Editorial Headings:** Keep tight negative letter-spacing for headlines to create an authoritative, print-grade feel.
- **Body & Transcripts:** `body-md` operates at `15px` with a generous `24px` line-height to guarantee effortless reading across multi-speaker dialogue blocks.
- **Timecode & Data:** All audio offsets, scrub durations, and file telemetry utilize monospaced numerical tables to preserve horizontal alignment during live playback scrubbing.

## Layout & Spacing
The layout model employs a flexible 12-column structure constrained by a maximum reading width of `1280px` (`80rem`) for dashboards, expanding to a full fluid viewport with sticky panels for the transcription editor.

- **Grid Structure:**
  - **Desktop (≥ 1024px):** 12 columns, `24px` gutter, `32px` minimum side margins. Dual-pane layout pairs the fixed waveform controller with a fluid transcript stream.
  - **Tablet (768px – 1023px):** 8 columns, `20px` gutter, `24px` margin. Controls collapse to sticky bottom docking.
  - **Mobile (< 768px):** 4 columns, `16px` gutter, `16px` margin. Audio player transitions to a persistent micro-bar; cards stack vertically.
- **Rhythm & Padding:** Component interiors conform strictly to an 8px modular baseline (`space-xs`, `space-md`, `space-lg`, `space-xl`). Dense data panels utilize `space-sm` (`12px`) internal spacing.

## Elevation & Depth
Elevation emphasizes tactile surface separation via crisp hairline boundaries coupled with ultra-diffused, ambient micro-shadows. Avoid high-contrast drop shadows.

- **Level 0 (Base Canvas):** `#FAFAF9` with zero shadow.
- **Level 1 (Card & Module Layer):** `#FFFFFF` background with a 1px solid border (`#E2E8F0`) and an ambient shadow: `0 1px 3px 0 rgba(15, 23, 42, 0.03), 0 1px 2px -1px rgba(15, 23, 42, 0.02)`.
- **Level 2 (Hover & Active Selection):** Border shifts to `#CBD5E1` with shadow: `0 4px 6px -1px rgba(15, 23, 42, 0.05), 0 2px 4px -2px rgba(15, 23, 42, 0.03)`.
- **Level 3 (Overlays, Floating Player, Modals):** Translucent base with glassmorphism: `rgba(255, 255, 255, 0.85)` fill, `backdrop-filter: blur(12px)`, hairline outline `rgba(226, 232, 240, 0.8)`, and shadow `0 20px 25px -5px rgba(15, 23, 42, 0.06), 0 8px 10px -6px rgba(15, 23, 42, 0.03)`.

## Shapes
The design system employs refined geometric curvature. Cards and containers use smooth `12px` to `16px` corners to create an approachable desktop workspace, while interactive elements balance touch targets with crisp profiles.

- **Outer Enclosures & Modals:** `rounded-xl` (`16px`) for clean framing.
- **Cards, File Dropzones & Audio Panels:** `rounded-lg` (`12px`).
- **Interactive Controls (Buttons, Form Inputs):** `rounded-md` (`8px`) to maintain structural precision.
- **Tags, Timestamps, & Badges:** Full pill (`9999px`) to visually separate metadata tokens from structural content boxes.

## Components

### Buttons
- **Primary:** Background `#4F46E5`, white text, hairline inset border `rgba(255, 255, 255, 0.15)`, smooth hover transition to `#4338CA`. Subtle active press scale (`0.98`).
- **Secondary / Outline:** Background `#FFFFFF`, border `1px solid #E2E8F0`, text `#0F172A`. On hover, background shifts to `#F8FAFC` and border to `#CBD5E1`.
- **Ghost / Utility:** Transparent background, text `#475569`, hover background `#F1F5F9`.

### File Upload & Drag-and-Drop Target
- Dashed perimeter border (`1.5px`) in `#CBD5E1`, with default fill `#FAFAF9`.
- Drag-over state shifts border to solid `#4F46E5` with an ambient glow fill of `rgba(79, 70, 229, 0.04)`.
- Center metadata shows clear file format support badges (`MP3`, `WAV`, `M4A`, `FLAC`) and size limits.

### Waveform Visualizer & Scrub Bar
- **Waveform Canvas:** Neutral slate vertical bars `#E2E8F0` on inactive segments; dynamic fill changes to `#2563EB` as playback advances.
- **Scrubber / Playhead:** A razor-thin `2px` vertical line in `#4F46E5` capped with a `6px` circular beacon.
- Hover scrub overlay displays a floating pill tooltip containing `mono-timestamp` (`00:14:32`).

### Transcript Speaker Cards & Dialogue Segments
- **Container:** Unbordered flat row on default; hovered segments receive a subtle `#F8FAFC` background with a left accent bar (`2px solid #4F46E5`).
- **Speaker Chip:** Compact pill badge displaying `Speaker 1` with distinct color accents (e.g., Indigo for Host, Cyan for Guest).
- **Timecode Trigger:** Interactive `mono-timestamp` triggering immediate playback jump to that syllable.
- **Confidence Highlighting:** Words transcribed with <80% confidence show a delicate amber underline (`#F59E0B`), revealing replacement suggestions on hover.

### Inputs & Search
- Inputs use `#FFFFFF` fill, `1px solid #E2E8F0`, and text `#0F172A`.
- Active focus state introduces a crisp ring: `0 0 0 3px rgba(79, 70, 229, 0.15)` with border color `#4F46E5`.

### Chips & Status Badges
- **Processing Status:** Pill badge with a soft animated pulse indicator (`#2563EB` for transcribing, `#10B981` for ready).
- Low-saturation pastel fills with high-contrast text (`bg: #EEF2FF`, `text: #3730A3`).